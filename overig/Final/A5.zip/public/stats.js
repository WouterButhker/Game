class GameStats {
    static currentGames = 0;
    static gamesPlayed = 0;
    static fastestGame = 80;
}

module.exports = GameStats;